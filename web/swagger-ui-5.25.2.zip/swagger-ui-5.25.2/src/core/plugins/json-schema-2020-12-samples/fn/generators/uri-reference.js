/**
 * @prettier
 */
const uriReferenceGenerator = () => "path/index.html"

export default uriReferenceGenerator
